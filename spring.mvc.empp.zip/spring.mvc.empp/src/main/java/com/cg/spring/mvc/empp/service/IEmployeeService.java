package com.cg.spring.mvc.empp.service;

public interface IEmployeeService {

}
