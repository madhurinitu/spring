package com.cg.spring.mvc.empp.repo;

public interface IEmployeeRepo {

}
