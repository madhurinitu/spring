package com.cg.spring.mvc.empp.controller;



	
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Controller;
	import org.springframework.stereotype.Repository;
	import org.springframework.web.bind.annotation.ModelAttribute;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RequestMethod;
	import org.springframework.web.bind.annotation.RequestParam;
	import org.springframework.web.servlet.ModelAndView;

import com.cg.spring.mvc.empp.beans.Employee;
import com.cg.spring.mvc.empp.service.IEmployeeService;


	@Controller
	public class EmployeeController {
		
		
		@Autowired
		IEmployeeService service;

		@RequestMapping(value="/getall",method=RequestMethod.GET)
		public ModelAndView getAllProducts()
		{
			ModelAndView mv= new ModelAndView("showall");
			mv.addObject("employees", service.getAllEmployee());
			return mv;
		}
		
		@RequestMapping(value="/Addp",method=RequestMethod.GET)
		public   ModelAndView addProduct() {
		 ModelAndView mv =new ModelAndView("Add");
		mv.addObject("command",new Employee());
		return mv;
		
	}
		@RequestMapping(value="/addproduct", method=RequestMethod.POST)
		public String add(Employee e)
		{
			service.add(e);
			return "redirect:/getall";
		}


		@RequestMapping(value="/search",method=RequestMethod.GET)
	    public ModelAndView searchproduct(@RequestParam("id") int id ) {
	   
	        ModelAndView mv = new ModelAndView("show");

	            mv.addObject("product",service.searchById(id));      

	     return mv;
		}
		@RequestMapping(value="/deleteemp/{id}",method = RequestMethod.GET)  
	    public ModelAndView delete(@PathVariable int id){  
			 ModelAndView mv = new ModelAndView("showone");
			return mv;
}
	}
