package com.cg.spring.mvc.repo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.cg.spring.mvc.bean.Product;
@Component 
public class ProductRepoImpl implements IproductRepo {
	List<Product> list= new ArrayList();
	public List<Product> getAllProducts() {
		return list;
	}
	public void add(Product p)
	{
		Product p1= new Product();
		p1.setId(list.size()+1);
		p1.setName("iphone 6s");
		p1.setPrice(98000);
		list.add(p1);
		
		Product p2= new Product();
		p2.setId(list.size() +1);
		p2.setName("samsung galaxy");
		p2.setPrice(8900);
		list.add(p2);
		p.setId(list.size() +1);
		list.add(p);
	
			}
	
	
	public Product SearchById(int id) {
		for(Product p:list)
		{
			if(p.getId()==id)
			return p;
		}
		return null;
	}
	public void DeleteById(Product p) {
		for(Product p1:list)
		{
			if(p.getProduct()==p)
				return p;
			
		}
				
	}
	public Product updateId(int id) {
		// TODO Auto-generated method stub
		return null;
	}
}

