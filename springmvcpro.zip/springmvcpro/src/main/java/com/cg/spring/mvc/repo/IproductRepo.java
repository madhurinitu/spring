package com.cg.spring.mvc.repo;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.spring.mvc.bean.Product;
@Repository
public interface IproductRepo {
List<Product>getAllProducts();
void add(Product p);
Product SearchById(int id);
void  DeleteById(Product p);
Product updateId(int id);
}
