package com.cg.spring.mvc.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.spring.mvc.bean.Product;
import com.cg.spring.mvc.service.IProductService;

@Controller
public class ProductController {
	
	
	@Autowired
	IProductService service;

	@RequestMapping(value="/getall",method=RequestMethod.GET)
	public ModelAndView getAllProducts()
	{
		ModelAndView mv= new ModelAndView("showall");
		mv.addObject("products", service.getAllProducts());
		return mv;
	}
	
	@RequestMapping(value="/Addp",method=RequestMethod.GET)
	public   ModelAndView addProduct() {
	 ModelAndView mv =new ModelAndView("Add");
	mv.addObject("command",new Product());
	return mv;
	
}
	@RequestMapping(value="/addproduct", method=RequestMethod.POST)
	public String add(Product p)
	{
		service.add(p);
		return "redirect:/getall";
	}


	@RequestMapping(value="/search",method=RequestMethod.GET)
    public ModelAndView searchproduct(@RequestParam("id") int id ) {
   
        ModelAndView mv = new ModelAndView("show");

            mv.addObject("product",service.searchById(id));      

     return mv;
	}
	@RequestMapping(value="/deleteemp/{id}",method = RequestMethod.GET)  
    public ModelAndView delete(@PathVariable int id){  
		 ModelAndView mv = new ModelAndView("showone");

         mv.addObject("product",service.DeleteById(id));      

  return mv;
	}

  @RequestMapping(value="/updte",method = RequestMethod.POST)  
    public ModelAndView update(@ModelAttribute("id") int  id){  
        service.update(id);  
        return new ModelAndView("redirect:/show");



