package com.cg.spring.jpa.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class CustomerRestController {
	@Autowired
	ICustomerService service;
@RequestMapping(value="/getall",method=RequestMethod.GET)
public List<Customer> getAll(){
	return service.getAll();
}
	@RequestMapping(value="/add",method=RequestMethod.POST)
	public String  add(@RequestBody Customer c){
		 service.add(c);
		return "success";
		
}
	@RequestMapping(value="/deleteemp/{id}",method = RequestMethod.GET)  
    public String delete(@PathVariable int id){  
		 ModelAndView mv = new ModelAndView("showall");
         mv.addObject("customer");
		return "deleted";
	}
		 @RequestMapping(value="/updte",method = RequestMethod.POST)  
		    public ModelAndView update(@ModelAttribute("id") int  id){  
		        service.update(id);  
		        return new ModelAndView("redirect:/show");

	}

}
