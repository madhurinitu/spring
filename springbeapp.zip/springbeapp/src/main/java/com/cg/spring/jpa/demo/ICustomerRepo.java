package com.cg.spring.jpa.demo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

public interface ICustomerRepo  extends CrudRepository<Customer,Integer>{


	



}
