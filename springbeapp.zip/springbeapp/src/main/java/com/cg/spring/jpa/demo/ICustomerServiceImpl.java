package com.cg.spring.jpa.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;



@Component
public  class ICustomerServiceImpl implements ICustomerService{

	@Autowired
	ICustomerRepo repo;
List<Customer> list =new ArrayList();
@Override
public List<Customer>getAll(){
	repo.findAll().forEach(list::add);
	return list;
}

@Override
public void add(Customer c) {
	repo.save(c);
}

@Override
public void DeleteById(Integer id) {
	repo.deleteById(id);
	
}
@Override
public void update(Integer id) {
	
	
repo.update(id);	
}
}
