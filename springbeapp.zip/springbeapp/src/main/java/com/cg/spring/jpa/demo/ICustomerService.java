package com.cg.spring.jpa.demo;

import java.util.List;

import org.springframework.stereotype.Service;
@Service
public interface ICustomerService {

	public List<Customer> getAll();
	public void add(Customer c);

void DeleteById(Integer id);

void update(Integer id);





}
