package com.cg.spring.mvc.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class FrontController {
@RequestMapping(value="/getall",method=RequestMethod.GET)
public ModelAndView getallCustomers() {
 ModelAndView mv =new ModelAndView("showall");
RestTemplate template= new RestTemplate();
List<Customer> list=template.getForObject("http://localhost:9395/getall",ArrayList.class);
mv.addObject("customers",list);
return mv;
}
@RequestMapping(value="/add",method=RequestMethod.GET)
public ModelAndView add() {
 ModelAndView mv =new ModelAndView("addcustomer");
mv.addObject("command",new Customer());
return mv;
}
@RequestMapping(value= "/addc",method=RequestMethod.POST)
public String addcustomer(Customer c)
{
	RestTemplate temp = new RestTemplate();
	temp.postForObject("http://localhost:9395/add", c, String.class);
	return "redirect:/getall";}
@RequestMapping(value="/delete/{id}",method = RequestMethod.GET)  
public ModelAndView delete(@PathVariable int id){  
	 ModelAndView mv = new ModelAndView("showall");
mv.addObject("");
return mv;
}
@RequestMapping(value="/update",method = RequestMethod.POST)  
public ModelAndView update(@ModelAttribute("id") int  id){  
    mv.update(id);  
    return new ModelAndView("redirect:/showall");
}
}
