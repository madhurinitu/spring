package com.cg.springcoreapp;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmployee {

	public static void main(String[] args) {
	ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("Spring.xml");

	Employee e1= context.getBean(Employee.class);
	//e1.setId(123);
//	e1.setName("mukesh");
	//e1.setSalary(1200);
			//System.out.println(e1);
			//Manager m1= context.getBean(Manager.class);
			//Manager m1=(Manager)context.getBean("mng");
		//	m1.setDeptnum(10);
			//m1.setProjectname("dlg");
		//	m1.setProjectcode("120");
					System.out.println(e1);
					context.close();

	}

}
  