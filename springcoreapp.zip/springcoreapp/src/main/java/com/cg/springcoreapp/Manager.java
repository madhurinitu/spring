package com.cg.springcoreapp;

public class Manager {

	int deptnum;
	String projectname;
	String projectcode;
	public int getDeptnum() {
		return deptnum;
	}
	public void setDeptnum(int deptnum) {
		this.deptnum = deptnum;
	}
	public String getProjectname() {
		return projectname;
	}
	public void setProjectname(String projectname) {
		this.projectname = projectname;
	}
	public String getProjectcode() {
		return projectcode;
	}
	public void setProjectcode(String projectcode) {
		this.projectcode = projectcode;
	}
	@Override
	public String toString() {
		return "Manager [deptnum=" + deptnum + ", projectname=" + projectname + ", projectcode=" + projectcode + "]";
	}
	
	
}
