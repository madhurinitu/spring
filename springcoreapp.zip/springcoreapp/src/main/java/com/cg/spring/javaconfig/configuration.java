package com.cg.spring.javaconfig;

public @interface configuration {

}
