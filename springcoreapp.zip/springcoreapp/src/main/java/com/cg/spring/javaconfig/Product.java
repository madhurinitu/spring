package com.cg.spring.javaconfig;

public class Product {
	private String productname;
private double productprice;


public Product()
{
	
}

	
public Product(String productname, double productprice) {
	super();
	this.productname = productname;
	this.productprice = productprice;
}

@Override
public String toString() {
	return "Product [productprice=" + productprice + ", productname=" + productname + "]";
}

public String getProductname() {
	return productname;
}

public void setProductname(String productname) {
	this.productname = productname;
}

public double getProductprice() {
	return productprice;
}

public void setProductprice(double productprice) {
	this.productprice = productprice;
}

}
